<?acf_add_options_page(array(
  'page_title' 	=> 'Sidebar',
  'menu_title'	=> 'Sidebar',
  'menu_slug' 	=> 'sidebar',
  'capability'	=> 'edit_posts',
  'redirect'		=> false,
  'post_id'	   	=> 'sidebar'
  ))?>