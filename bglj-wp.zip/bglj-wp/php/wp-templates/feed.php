<?/**
   * Template Name:       Feed
   * Template Post Type:  page
   * 
   * @package WordPress
   * @subpackage wp_bglj
   */?>