<template>
  <b><code>hello world</code></b>
</template>
